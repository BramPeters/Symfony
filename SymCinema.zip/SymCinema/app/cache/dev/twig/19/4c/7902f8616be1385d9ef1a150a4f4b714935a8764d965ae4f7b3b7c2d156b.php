<?php

/* CinemaCinemaBundle:Movie:show.html.twig */
class __TwigTemplate_194c7902f8616be1385d9ef1a150a4f4b714935a8764d965ae4f7b3b7c2d156b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("CinemaCinemaBundle::layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CinemaCinemaBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["movie"]) ? $context["movie"] : $this->getContext($context, "movie")), "title"), "html", null, true);
    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        // line 7
        echo "    <article class=\"movie\">
        <header>
            
            <h2>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["movie"]) ? $context["movie"] : $this->getContext($context, "movie")), "title"), "html", null, true);
        echo "</h2>
        </header>
        <img src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "images/", 1 => $this->getAttribute((isset($context["movie"]) ? $context["movie"] : $this->getContext($context, "movie")), "image")))), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["movie"]) ? $context["movie"] : $this->getContext($context, "movie")), "title"), "html", null, true);
        echo " image not found\" class=\"large\" />
        <div>
            <p>Eerste speeldag: <time datetime=\"";
        // line 14
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["movie"]) ? $context["movie"] : $this->getContext($context, "movie")), "created"), "c"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["movie"]) ? $context["movie"] : $this->getContext($context, "movie")), "created"), "l, j F, Y"), "html", null, true);
        echo "</time></p>
            <p>Filmduur: ";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["movie"]) ? $context["movie"] : $this->getContext($context, "movie")), "duration"), "html", null, true);
        echo " minuten</p>
            <p>Imdb: <a href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["movie"]) ? $context["movie"] : $this->getContext($context, "movie")), "imdblink"), "html", null, true);
        echo "\" target=\"_newtab\">";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["movie"]) ? $context["movie"] : $this->getContext($context, "movie")), "title"), "html", null, true);
        echo "</a></p>
            
            <section class=\"showings\" id=\"showings\">
                <section class=\"previous-showings\">
                    <h3>Eerstvolgende vertoningen:</h3>
                    ";
        // line 21
        $this->env->loadTemplate("CinemaCinemaBundle:Showing:index.html.twig")->display(array_merge($context, array("showings" => (isset($context["showings"]) ? $context["showings"] : $this->getContext($context, "showings")))));
        // line 22
        echo "                </section>
            </section>
        </div>
    </article>
";
    }

    public function getTemplateName()
    {
        return "CinemaCinemaBundle:Movie:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 22,  75 => 21,  65 => 16,  61 => 15,  55 => 14,  48 => 12,  43 => 10,  38 => 7,  35 => 6,  29 => 4,);
    }
}
