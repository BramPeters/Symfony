<?php

/* CinemaCinemaBundle:Page:about.html.twig */
class __TwigTemplate_5d9499434b83fef96cf025a642973bff59910c46a2c57d304c8f8274fc383e0c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("CinemaCinemaBundle::layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CinemaCinemaBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "About";
    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        // line 7
        echo "    <header>
        <h1>About SymCinema</h1>
    </header>
    <article>
        <p>
        De bedoeling was het aanmaken van een webshop dat dient als kassa voor een cinema (met 3 zalen).
        Deze site moet dus de mogelijkheid hebben om:
        <ul>
        <li>- een filmprogramma aan te maken</li>
        <li>- ticketjes te bestellen voor een film naar keuze</li>
        <li>- extra's te kopen (eten, drinken, cheques, ...)</li>
        </ul>
        <br>Dit alles door gebruik te maken van Symfony, PHP, Twig.</p>
        
        Aanleiding hiervan is om te oefenen in het gebruik van Symfony en om een bestaand voorbeeld aan te passen.
        
        
        
        </p>
    </article>
";
    }

    public function getTemplateName()
    {
        return "CinemaCinemaBundle:Page:about.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 7,  35 => 6,  29 => 4,);
    }
}
