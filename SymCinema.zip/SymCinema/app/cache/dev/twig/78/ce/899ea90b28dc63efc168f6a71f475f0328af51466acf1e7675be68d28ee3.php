<?php

/* CinemaCinemaBundle:Showing:index.html.twig */
class __TwigTemplate_78ce899ea90b28dc63efc168f6a71f475f0328af51466acf1e7675be68d28ee3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
";
        // line 3
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["showings"]) ? $context["showings"] : $this->getContext($context, "showings")));
        $context['_iterated'] = false;
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["showing"]) {
            // line 4
            echo "    <article class=\"showing ";
            echo twig_escape_filter($this->env, twig_cycle(array(0 => "odd", 1 => "even"), $this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "index0")), "html", null, true);
            echo "\" id=\"showing-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "id"), "html", null, true);
            echo "\">
        <header>
            <p><a href=\"\"><span class=\"highlight\"><time datetime=\"";
            // line 6
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "startingtime"), "c"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "startingtime"), "l, j F, Y"), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "startingtime"), "H:i"), "html", null, true);
            echo "</time></span> | Plaatsen: ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "soldtickets"), "html", null, true);
            echo " van de ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "hallId"), "seats"), "html", null, true);
            echo " verkocht.</a></p>
        </header>
    </article>
";
            $context['_iterated'] = true;
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        if (!$context['_iterated']) {
            // line 10
            echo "    <p>Er zijn geen geplande vertoningen voor deze film.</p>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['showing'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "CinemaCinemaBundle:Showing:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 10,  40 => 4,  22 => 3,  19 => 2,  77 => 22,  75 => 21,  65 => 16,  61 => 15,  55 => 14,  48 => 6,  43 => 10,  38 => 7,  35 => 6,  29 => 4,);
    }
}
