<?php

/* CinemaCinemaBundle:Page:sidebar.html.twig */
class __TwigTemplate_50ba1f47fae6dfcadf8e82584f9086657f924508296c0515ee4eeb9d232cba0c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
<section class=\"section\">
    <header>
        <h3>Voorstellingen van vandaag: ";
        // line 5
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "d/m/Y"), "html", null, true);
        echo "</h3>
    </header>
    <p class=\"tags\">
    
    <div>
   <h2 style=\"background-color: green; color:white; opacity:0.7; padding: 3px\">Groene Zaal</h2>
        ";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["todaysMovies"]) ? $context["todaysMovies"] : $this->getContext($context, "todaysMovies")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["showing"]) {
            echo "        
        ";
            // line 12
            if (($this->getAttribute($this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "hallId"), "name") == "Groene")) {
                // line 13
                echo "        <span class=\"weight-\">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "startingtime"), "H:i"), "html", null, true);
                echo "<br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "MovieId"), "title"), "html", null, true);
                echo "</span><br>
        ";
            }
            // line 15
            echo "        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 16
            echo "            <p>Er spelen geen films in deze zaal vandaag.</p>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['showing'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "     </div>       
    
    <div>
    <h2 style=\"background-color: red; color:white; opacity:0.7; padding: 3px\">Rode Zaal</h2>
        ";
        // line 22
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["todaysMovies"]) ? $context["todaysMovies"] : $this->getContext($context, "todaysMovies")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["showing"]) {
            echo "        
        ";
            // line 23
            if (($this->getAttribute($this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "hallId"), "name") == "Rode")) {
                // line 24
                echo "        <span class=\"weight-\">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "startingtime"), "H:i"), "html", null, true);
                echo "<br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "MovieId"), "title"), "html", null, true);
                echo "</span><br>
        ";
            }
            // line 26
            echo "        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 27
            echo "            <p>Er spelen geen films in deze zaal vandaag.</p>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['showing'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "    </div>
    
    <div>
   <h2 style=\"background-color: blue; color:white; opacity:0.7; padding: 3px\">Blauwe Zaal</h2>
        ";
        // line 33
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["todaysMovies"]) ? $context["todaysMovies"] : $this->getContext($context, "todaysMovies")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["showing"]) {
            echo "        
        ";
            // line 34
            if (($this->getAttribute($this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "hallId"), "name") == "Blauwe")) {
                // line 35
                echo "        <span class=\"weight-\">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "startingtime"), "H:i"), "html", null, true);
                echo "<br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "MovieId"), "title"), "html", null, true);
                echo "</span><br>
        ";
            }
            // line 37
            echo "        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 38
            echo "            <p>Er spelen geen films in deze zaal vandaag.</p>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['showing'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "  
            </div>
            
    </p>
</section>";
    }

    public function getTemplateName()
    {
        return "CinemaCinemaBundle:Page:sidebar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  132 => 39,  125 => 38,  120 => 37,  112 => 35,  110 => 34,  103 => 33,  97 => 29,  90 => 27,  85 => 26,  77 => 24,  75 => 23,  68 => 22,  62 => 18,  55 => 16,  50 => 15,  42 => 13,  40 => 12,  33 => 11,  24 => 5,  19 => 2,);
    }
}
