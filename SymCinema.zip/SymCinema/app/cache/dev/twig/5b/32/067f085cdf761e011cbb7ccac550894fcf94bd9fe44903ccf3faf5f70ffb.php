<?php

/* CinemaCinemaBundle:Page:index.html.twig */
class __TwigTemplate_5b32067f085cdf761e011cbb7ccac550894fcf94bd9fe44903ccf3faf5f70ffb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("CinemaCinemaBundle::layout.html.twig");

        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CinemaCinemaBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_javascripts($context, array $blocks = array())
    {
        // line 6
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

            <script src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/cinemacinema/js/lib/jquery-1.11.0.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/cinemacinema/js/lib/jquery-ui-1.10.4.custom.min.js"), "html", null, true);
        echo "\"></script>
            
            <script type=\"text/javascript\">
\t\$(function(){
\t\t\$('#datepicker').datepicker({
\t\t\tinline: true,
\t\t\tshowOtherMonths: true,
\t\t\tdayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
\t\t});
\t});
</script>
            
            
        ";
    }

    // line 28
    public function block_body($context, array $blocks = array())
    {
        // line 29
        echo "<div style=\"text-align: center\">
    <div id=\"datepicker\"></div>  
    <h2>Kies uw film voor:</h2>
    <h2>";
        // line 32
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "d/m/Y"), "html", null, true);
        echo "</h2>
    <div style=\"float:right; width:500px; background-color:#eee;\">
            <table style=\" height:200px; \">
                <th class=\"info\" style=\"width:10em;padding:15px;\">Starttijd v.d. film</th>
                <th class=\"info\" style=\"width:10em;padding:15px;\">Filmtitel</th>
                <th class=\"info\" style=\"width:10em;padding:15px;\">Resterende vrije plaatsen</th>
                <th class=\"info\" style=\"width:10em;padding:15px;\">Tickets reserveren</th>
        ";
        // line 39
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["movies"]) ? $context["movies"] : $this->getContext($context, "movies")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["showing"]) {
            // line 40
            echo "            
    ";
            // line 42
            echo "                <tr style=\"background-color:white\">
                    <td>";
            // line 43
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "startingtime"), "d/m/Y - H:i"), "html", null, true);
            echo "</td>
                    <td style=\"width:12em;\"><a href=\"";
            // line 44
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("CinemaCinemaBundle_movie_show", array("id" => $this->getAttribute($this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "MovieId"), "id"))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "MovieId"), "title"), "html", null, true);
            echo " (info)</a></td>
                    <td style=\"width:10em;\">";
            // line 45
            echo twig_escape_filter($this->env, ($this->getAttribute($this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "hallId"), "seats") - $this->getAttribute((isset($context["showing"]) ? $context["showing"] : $this->getContext($context, "showing")), "soldtickets")), "html", null, true);
            echo "</td>
                    <td style=\"width:10em;\"><a href=\"\">Reserveren</a></td>
                </tr>
        
        ";
            // line 50
            echo "            
        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 52
            echo "            <p>Er zijn geen geplande voorstellingen voor deze dag.</p>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['showing'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 54
        echo "            
            </table>
            </div>
     
    
    
    <!-- OUDE VERSIE -->
    <!-- 
    <div style=\"float:right; width:500px; background-color:#eee;\">
        <table style=\" height:200px; \">
            <h3>Ochtend</h3>
            <div>
                <th class=\"info\" style=\"width:10em;\">Uur</th>
                <th class=\"info\" style=\"width:10em;\">Naam</th>
                <th class=\"info\">Plaatsen</th>
                <th class=\"info\">Infolink</th>
            </div>

            <div >
                <tr style=\"background-color:white\">
                    <td>10:20</td>
                    <td style=\"width:10em;\">Belle en het Beest</td>
                    <td style=\"width:10em;\">120</td>
                    <td style=\"width:10em;\"><a href=\"\">Infolink</a></td>
                </tr>
            </div>
            <div>
                <tr style=\"background-color:white\">
                    <td style=\"background-color:white\">10:20</td>
                    <td style=\"width:10em;background-color:white\">Pocahontas</td>
                    <td style=\"width:10em;background-color:white\">87</td>
                    <td style=\"width:10em;background-color:white\"><a href=\"\">Infolink</a></td>
                </tr>
            </div>
            <div>
                <tr style=\"background-color:white\">
                    <td>10:30</td>
                    <td style=\"width:10em;\">Dumbo</td>
                    <td style=\"width:10em;\">57</td>
                    <td style=\"width:10em;\"><a href=\"\">Infolink</a></td>
                </tr>
            </div>
        </table>
        <table style=\" height:200px;\">

            <tr><h3>Middag</h3></tr>

            <div>
                <th class=\"info\" style=\"width:10em;\">Uur</th>
                <th class=\"info\" style=\"width:10em;\">Naam</th>
                <th class=\"info\">Plaatsen</th>
                <th class=\"info\">Infolink</th>
            </div>

            <div>
                <tr style=\"background-color:white\">
                    <td >14:20</td>
                    <td style=\"width:10em;\">Belle en het Beest</td>
                    <td style=\"width:10em;\">110</td>
                    <td style=\"width:10em;\"><a href=\"\">Infolink</a></td>
                </tr>
            </div>
            <div>
                <tr style=\"background-color:white\">
                    <td >14:20</td>
                    <td style=\"width:10em;\">Doornroosje</td>
                    <td style=\"width:10em;\">75</td>
                    <td style=\"width:10em;\"><a href=\"\">Infolink</a></td>
                </tr>
            </div>
        </table>
        <table style=\" height:200px;\">
            <tr><h3>Avond</h3></tr>

            <div>
                <th class=\"info\" style=\"width:10em;\">Uur</th>
                <th class=\"info\" style=\"width:10em;\">Naam</th>
                <th class=\"info\">Plaatsen</th>
                <th class=\"info\">Infolink</th>
            </div>

            <div>
                <tr style=\"background-color:white\">
                    <td >19:45</td>
                    <td style=\"width:10em;\">Belle en het Beest</td>
                    <td style=\"width:10em;\">120</td>
                    <td style=\"width:10em;\"><a href=\"\">Infolink</a></td>
                </tr>
            </div>
            <div>
                <tr style=\"background-color:white\">
                    <td >19:30</td>
                    <td style=\"width:10em;\">Assepoester</td>
                    <td style=\"width:10em;\">33</td>
                    <td style=\"width:10em;\"><a href=\"\">Infolink</a></td>
                </tr>
            </div>
        </table>
        <table style=\" height:200px;\">
            <tr><h3>Nacht</h3></tr>


            <div>
                <th class=\"info\" style=\"width:10em;\">Uur</th>
                <th class=\"info\" style=\"width:10em;\">Naam</th>
                <th class=\"info\">Plaatsen</th>
                <th class=\"info\">Infolink</th>
            </div>

            <div>
                <tr style=\"background-color:white\">
                    <td >22:10</td>
                    <td style=\"width:10em;\">Belle en het Beest</td>
                    <td style=\"width:10em;\">12</td>
                    <td style=\"width:10em;\"><a href=\"\">Infolink</a></td>
                </tr>
            </div>
            <div>
                <tr style=\"background-color:white\">
                    <td >22:15</td>
                    <td style=\"width:10em;\">Assepoester</td>
                    <td style=\"width:10em;\">35</td>
                    <td style=\"width:10em;\"><a href=\"\">Infolink</a></td>
                </tr>
            </div>
            <div>
                <tr style=\"background-color:white\">
                    <td >22:20</td>
                    <td style=\"width:10em;\">Dumbo</td>
                    <td style=\"width:10em;\">55</td>
                    <td style=\"width:10em;\"><a href=\"\">Infolink</a></td>
                </tr>
            </div>
        </table>
    </div>
    -->
    <!-- OUDE VERSIE -->
</div>
";
    }

    public function getTemplateName()
    {
        return "CinemaCinemaBundle:Page:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  118 => 54,  111 => 52,  105 => 50,  98 => 45,  92 => 44,  88 => 43,  85 => 42,  82 => 40,  77 => 39,  67 => 32,  62 => 29,  59 => 28,  41 => 9,  37 => 8,  32 => 6,  29 => 5,);
    }
}
