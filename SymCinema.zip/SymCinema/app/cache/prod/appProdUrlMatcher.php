<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // CinemaCinemaBundle_homepage
        if (rtrim($pathinfo, '/') === '') {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_CinemaCinemaBundle_homepage;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'CinemaCinemaBundle_homepage');
            }

            return array (  '_controller' => 'Cinema\\CinemaBundle\\Controller\\PageController::indexAction',  '_route' => 'CinemaCinemaBundle_homepage',);
        }
        not_CinemaCinemaBundle_homepage:

        // CinemaCinemaBundle_about
        if ($pathinfo === '/about') {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_CinemaCinemaBundle_about;
            }

            return array (  '_controller' => 'Cinema\\CinemaBundle\\Controller\\PageController::aboutAction',  '_route' => 'CinemaCinemaBundle_about',);
        }
        not_CinemaCinemaBundle_about:

        // CinemaCinemaBundle_movielist
        if ($pathinfo === '/movielist') {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_CinemaCinemaBundle_movielist;
            }

            return array (  '_controller' => 'Cinema\\CinemaBundle\\Controller\\PageController::movielistAction',  '_route' => 'CinemaCinemaBundle_movielist',);
        }
        not_CinemaCinemaBundle_movielist:

        // CinemaCinemaBundle_movie_show
        if (preg_match('#^/(?P<id>\\d+)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_CinemaCinemaBundle_movie_show;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'CinemaCinemaBundle_movie_show')), array (  '_controller' => 'Cinema\\CinemaBundle\\Controller\\MovieController::showAction',));
        }
        not_CinemaCinemaBundle_movie_show:

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
