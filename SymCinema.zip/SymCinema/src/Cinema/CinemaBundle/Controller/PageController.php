<?php

// src/Cinema/CinemaBundle/Controller/PageController.php

namespace Cinema\CinemaBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class PageController extends Controller {

    public function indexAction() {
        $em = $this->getDoctrine()
                ->getManager();
        
    if(isset($_GET["date"]) && $_GET["date"] !== null){
        $date=$_GET["date"];
    }else{
        $date="2014-05-05";
    }

        $movies = $em->getRepository('CinemaCinemaBundle:Showing')
                ->getMoviesByDate($date);
        
        
        return $this->render('CinemaCinemaBundle:Page:index.html.twig', array(
                    'movies' => $movies
        ));
    }

    public function aboutAction() {
        return $this->render('CinemaCinemaBundle:Page:about.html.twig');
    }
    
    public function loginAction()
{
    return $this->render('CinemaCinemaBundle:Page:login.html.twig');
}

    public function MovieListAction() {
        $em = $this->getDoctrine()
                ->getManager();

        $movies = $em->getRepository('CinemaCinemaBundle:Movie')
                ->getAllMovies();

        return $this->render('CinemaCinemaBundle:Page:movielist.html.twig', array(
                    'movies' => $movies
        ));
    }

    public function sidebarAction() {
        
        $em = $this->getDoctrine()
                ->getManager();

        $todaysMovies = $em->getRepository('CinemaCinemaBundle:Showing')
                ->getTodaysMovies();
        
        var_dump($todaysMovies);

        return $this->render('CinemaCinemaBundle:Page:sidebar.html.twig', array(
                    'todaysMovies' => $todaysMovies
        ));
    }

}