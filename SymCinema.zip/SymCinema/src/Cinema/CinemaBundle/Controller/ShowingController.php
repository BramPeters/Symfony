<?php
// src/Cinema/CinemaBundle/Controller/ShowingController.php

namespace Cinema\CinemaBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

/**
 * Movie controller.
 */
class ShowingController extends Controller
{
    /**
     * Show a Movie entry
     */
    public function showAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $movie = $em->getRepository('CinemaCinemaBundle:Movie')->find($id);

        if (!$movie) {
            throw $this->createNotFoundException('Unable to find Movie post.');
        }

        return $this->render('CinemaCinemaBundle:Movie:show.html.twig', array(
            'movie'      => $movie,
        ));
    }
}