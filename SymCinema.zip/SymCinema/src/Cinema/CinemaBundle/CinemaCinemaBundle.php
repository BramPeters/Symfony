<?php

namespace Cinema\CinemaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CinemaCinemaBundle extends Bundle
{
}
